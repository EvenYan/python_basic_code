from django.apps import AppConfig


class ShowPicConfig(AppConfig):
    name = 'show_pic'
