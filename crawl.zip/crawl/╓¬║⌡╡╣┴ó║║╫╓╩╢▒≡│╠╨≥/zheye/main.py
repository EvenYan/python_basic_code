from zheye import zheye

z = zheye()
positions = z.Recognize("./realcap/c.gif")
print(positions)
